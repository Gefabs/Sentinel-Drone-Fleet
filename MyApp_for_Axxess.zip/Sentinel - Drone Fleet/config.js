// Set your API server host when hosting UI separately (e.g. on Axess).
// Leave empty to use current page hostname (for local or same-server setup).
// Example for Oracle: window.SENTINEL_API_HOST = '123.45.67.89';
window.SENTINEL_API_HOST = '';
